r = float(input('Raio do círculo: '))
area = 3.14 * (r ** 2)

print ('Área do círculo: ', area)
