m1=float(input("Digite nota 1: "))
m2=float(input("Digite nota 2: "))
m3=float(input("Digite nota 3: "))
m4=float(input("Digite nota 4: "))

media= (m1+m2+m3+m4)/4

print("A sua média é: ",media)
