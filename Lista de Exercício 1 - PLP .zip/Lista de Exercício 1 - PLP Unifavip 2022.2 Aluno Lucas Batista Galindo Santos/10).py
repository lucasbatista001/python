c= float(input("Temperatura em Celsius: "))

f= (9*c/5 + 32)

print ("Temperatura em Fahrenheit:", f, "°F" )
