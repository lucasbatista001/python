
mun = int(input("Entre com um munero? :"))
print(" O número informado foi: ", mun )
