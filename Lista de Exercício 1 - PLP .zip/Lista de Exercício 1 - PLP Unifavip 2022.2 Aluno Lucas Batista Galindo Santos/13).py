altura1 = float(input("Digite sua altura em metros: "))

a = 72.7 * altura1
b = a - 58

c = 62.1 * altura1
d = c - 44.7

print(f"Peso ideal para homens seria: {b:,.2f}")
print(f"Peso ideal para mulheres seria: {d:,.2f}"),
