m= int(input('Informe o valor em metros: '))
c= m * 100

print ('O valor em centimetros é :', c)
