altura = float(input("Digite a altura do quadrado em metros: "))
largura = float(input("Digite a largura do quadrado em metros: "))

a = altura * largura

print ("O dobro da area é: ", a * 2, "m²")
