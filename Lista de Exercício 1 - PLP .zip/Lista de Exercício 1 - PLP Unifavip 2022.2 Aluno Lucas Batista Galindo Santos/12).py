altura= float(input("Digite sua altura em metros: "))

a = 72.7 * altura
b = a - 58

print (f"Seu peso ideal seria: {b:,.2f}"),
