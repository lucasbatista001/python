h= float(input("Quanto você ganha por hora? :"))
m= float(input("Número de horas trabalhadas no mês? :"))

s= h * m

print("Total do seu salário no referido mês, é: ", s)
