n1 = int(input('Número inteiro: '))
n2 = int(input('Número inteiro: '))
nr = float(input('Número real: '))

print ("O produto do dobro do primeiro com metade do segundo:", ((2*n1) * (n2/2)))
print ("A soma do triplo do primeiro com o terceiro:", (3 * n1) + nr)
print ("O terceiro elevado ao cubo:", nr**3)
