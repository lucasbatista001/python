f= float(input("Temperatura em graus Fahrenheit: "))

c = 5 * ((f-32) / 9)

print("Temperatura em graus Celsius é: ", c, "°C" )
