a = int(input("Entre com um munero? :"))
b = int(input("Entre com um munero? :"))

c = a + b

print( "A soma é:", c )
